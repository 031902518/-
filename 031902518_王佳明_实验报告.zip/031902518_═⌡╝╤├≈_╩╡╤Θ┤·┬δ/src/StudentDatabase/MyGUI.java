package StudentDatabase;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.sql.Connection;

public class MyGUI extends JFrame {
        public void Init1(boolean vis){
                Container container =this.getContentPane();//容器，放东西
                Button back=new Button("Return Menu");
                back.setBackground(Color.PINK);
                back.setBounds(680,400,100,50);
                back.addActionListener(new returnback());
                container.add(back);
                //定义变量
                JButton button1=new JButton("插入");
                button1.setBackground(Color.PINK);
                JButton button2=new JButton("修改");
                button2.setBackground(Color.PINK);
                JButton button3=new JButton("删除");
                button3.setBackground(Color.PINK);
                JButton button4=new JButton("查询");
                button4.setBackground(Color.PINK);
                JTextArea textArea = new JTextArea(20, 50);
                textArea.setBackground(Color.PINK);
                textArea.setLineWrap(true);
                textArea.setText("默认输出框");
                //Scroll面板
                JScrollPane scrollPane = new JScrollPane(textArea);

                //添加
                container.setLayout(null);
                button1.setBounds(20,0,80,40);
                button2.setBounds(170,0,80,40);
                button3.setBounds(320,0,80,40);
                button4.setBounds(470,0,80,40);
                scrollPane.setBounds(50,45,750,50);

                URL resource=MainInit.class.getResource("1.png");
                Icon icon =new ImageIcon(resource);
                //把这个图标放在按钮上
                JLabel ll =new JLabel();
                ll.setIcon(icon);
                ll.setBounds(0,0,800,450);
                container.add(ll);
                JComboBox status =new JComboBox();
                status.addItem("学生表");
                status.addItem("学生个数");
                status.addItem("学生最大年龄");
                status.addItem("学生最小年龄");
                status.addItem("学生平均年龄");
                status.setBackground(Color.PINK);
                status.setBounds(620,0,100,40);
               container.add(status);

                container.add(scrollPane);
                container.add(button1);
                container.add(button2);
                container.add(button3);
                container.add(button4);

                this.setVisible(vis);
                this.setSize(800,488);
                this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

                Button1Listener b1=new Button1Listener(textArea);
                button1.addActionListener(b1);

                Button2Listener b2=new Button2Listener(textArea);
                button2.addActionListener(b2);


                Button3Listener b3=new Button3Listener(textArea);
                button3.addActionListener(b3);

                Button4Listener b4=new Button4Listener(textArea);
                button4.addActionListener(b4);

                Button5Listener b5=new Button5Listener(textArea,status);
                status.addActionListener(b5);

        }
        public void Init2(boolean vis){
                Container container =this.getContentPane();//容器，放东西
                Button back=new Button("Return Menu");
                back.setBackground(Color.YELLOW);
                back.setBounds(680,400,100,50);
                back.addActionListener(new returnback());
                container.add(back);
                //定义变量
                URL resource=MainInit.class.getResource("1.png");
                Icon icon =new ImageIcon(resource);
                //把这个图标放在按钮上
                JLabel ll =new JLabel();
                ll.setIcon(icon);
                ll.setBounds(0,0,800,450);
                container.add(ll);
                JButton button6=new JButton("插入");
                JButton button7=new JButton("修改");
                JButton button8=new JButton("删除");
                JButton button9=new JButton("查询");
                JTextArea textArea = new JTextArea(20, 50);
                textArea.setText("默认输出框");
                textArea.setBackground(Color.YELLOW);

                //Scroll面板
                JScrollPane scrollPane = new JScrollPane(textArea);
                scrollPane.setBackground(Color.YELLOW);

                //添加
                container.setLayout(null);
                button6.setBounds(20,0,80,40);
                button6.setBackground(Color.YELLOW);
                button7.setBounds(170,0,80,40);
                button7.setBackground(Color.YELLOW);
                button8.setBounds(320,0,80,40);
                button8.setBackground(Color.YELLOW);
                button9.setBounds(470,0,80,40);
                button9.setBackground(Color.YELLOW);
                scrollPane.setBounds(50,45,750,50);

                JComboBox status =new JComboBox();
                status.addItem(null);
                status.addItem("课程个数");
                status.addItem("课程最大学分");
                status.addItem("课程最小学分");
                status.addItem("课程平均学分");
                status.setBounds(620,0,100,40);
                status.setBackground(Color.YELLOW);
                container.add(status);

                container.add(scrollPane);
                container.add(button6);
                container.add(button7);
                container.add(button8);
                container.add(button9);

                this.setVisible(vis);
                this.setSize(800,488);
                this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

                Button6Listener b6=new Button6Listener(textArea);
                button6.addActionListener(b6);

                Button7Listener b7=new Button7Listener(textArea);
                button7.addActionListener(b7);


                Button8Listener b8=new Button8Listener(textArea);
                button8.addActionListener(b8);

                Button9Listener b9=new Button9Listener(textArea);
                button9.addActionListener(b9);

                Button10Listener b10=new Button10Listener(textArea,status);
                status.addActionListener(b10);

        }

        public void Init3(boolean vis){
                Container container =this.getContentPane();//容器，放东西
                Button back=new Button("Return Menu");
                back.setBounds(680,400,100,50);
                back.addActionListener(new returnback());
                back.setBackground(Color.GREEN);
                container.add(back);
                //定义变量
                URL resource=MainInit.class.getResource("1.png");
                Icon icon =new ImageIcon(resource);
                //把这个图标放在按钮上
                JLabel ll =new JLabel();
                ll.setIcon(icon);
                ll.setBounds(0,0,800,450);
                container.add(ll);
                JButton button11=new JButton("插入");
                button11.setBackground(Color.GREEN);
                JButton button12=new JButton("修改");
                button12.setBackground(Color.GREEN);
                JButton button13=new JButton("删除");
                button13.setBackground(Color.GREEN);
                JButton button14=new JButton("查询");
                button14.setBackground(Color.GREEN);
                JTextArea textArea = new JTextArea(20, 50);
                textArea.setText("默认输出框");
                textArea.setBackground(Color.GREEN);
                //Scroll面板
                JScrollPane scrollPane = new JScrollPane(textArea);

                //添加
                container.setLayout(null);
                button11.setBounds(20,0,80,40);
                button12.setBounds(170,0,80,40);
                button13.setBounds(320,0,80,40);
                button14.setBounds(470,0,80,40);
                scrollPane.setBounds(50,45,750,50);

                container.add(scrollPane);
                container.add(button11);
                container.add(button12);
                container.add(button13);
                container.add(button14);

                this.setVisible(vis);
                this.setSize(800,488);
                this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

                Button11Listener b11=new Button11Listener(textArea);
                button11.addActionListener(b11);

                Button12Listener b12=new Button12Listener(textArea);
                button12.addActionListener(b12);


                Button13Listener b13=new Button13Listener(textArea);
                button13.addActionListener(b13);

                Button14Listener b14=new Button14Listener(textArea);
                button14.addActionListener(b14);

        }
}
class Button1Listener implements ActionListener {
        public  JTextArea tex;
        public Button1Listener( JTextArea textArea){
                this.tex=textArea;
        }
        public void actionPerformed(ActionEvent e){
                new Myinsert(tex);
        }

}

class Button2Listener implements  ActionListener{
        public JTextArea tex;
        public Button2Listener( JTextArea textArea){
                this.tex=textArea;
        }
        public void actionPerformed(ActionEvent e){
                new Myupdate(tex);
        }
}
class Button3Listener implements  ActionListener{
        public  JTextArea tex;
        public Button3Listener( JTextArea textArea){
                this.tex=textArea;
        }
        public void actionPerformed(ActionEvent e){
                new Mydelete(tex);
        }

}
class Button4Listener implements  ActionListener{
        public  JTextArea tex;
        public Button4Listener( JTextArea textArea){
                this.tex=textArea;
        }
        public void actionPerformed(ActionEvent e){
                Student stud=new Student();
                Connection c=stud.stu_connect();
               stud.stu_search(c,tex);
        }
}
class Button5Listener implements  ActionListener{
        public  JTextArea tex;
        public JComboBox flag;
        public Button5Listener( JTextArea textArea,JComboBox flag){
                this.tex=textArea;
                this.flag=flag;
        }
        public void actionPerformed(ActionEvent e){
                Student stud=new Student();
                Connection c=stud.stu_connect();
                stud.stu_search2(c,tex,flag);
        }
}
class Button6Listener implements ActionListener {
        public  JTextArea tex;
        public Button6Listener( JTextArea textArea){
                this.tex=textArea;
        }
        public void actionPerformed(ActionEvent e){
                new Myinsert2(tex);
        }

}
class Button7Listener implements  ActionListener{
        public JTextArea tex;
        public Button7Listener( JTextArea textArea){
                this.tex=textArea;
        }
        public void actionPerformed(ActionEvent e){
                new Myupdate2(tex);
        }
}
class Button8Listener implements  ActionListener{
        public  JTextArea tex;
        public Button8Listener( JTextArea textArea){
                this.tex=textArea;
        }
        public void actionPerformed(ActionEvent e){
                new Mydelete2(tex);
        }

}
class Button9Listener implements  ActionListener{
        public  JTextArea tex;
        public Button9Listener( JTextArea textArea){
                this.tex=textArea;
        }
        public void actionPerformed(ActionEvent e){
                Course cou=new Course();
                Connection c=cou.cou_connect();
                cou.cou_search(c,tex);
        }
}
class Button10Listener implements  ActionListener{
        public  JTextArea tex;
        public JComboBox flag;
        public Button10Listener( JTextArea textArea,JComboBox flag){
                this.tex=textArea;
                this.flag=flag;
        }
        public void actionPerformed(ActionEvent e){
                Course cou=new Course();
                Connection c=cou.cou_connect();
                cou.cou_search2(c,tex,flag);
        }
}
class Button11Listener implements  ActionListener{
        public  JTextArea tex;
        public Button11Listener( JTextArea textArea){
                this.tex=textArea;
        }
        public void actionPerformed(ActionEvent e){
                new Myinsert3(tex);
        }
}
class Button12Listener implements  ActionListener{
        public  JTextArea tex;
        public Button12Listener( JTextArea textArea){
                this.tex=textArea;
        }
        public void actionPerformed(ActionEvent e){
                new Myupdate3(tex);

        }
}
class Button13Listener implements  ActionListener{
        public  JTextArea tex;
        public Button13Listener( JTextArea textArea){
                this.tex=textArea;
        }
        public void actionPerformed(ActionEvent e){

                new Mydelete3(tex);
        }
}
class Button14Listener implements  ActionListener{
        public  JTextArea tex;
        public Button14Listener( JTextArea textArea){
                this.tex=textArea;
        }
        public void actionPerformed(ActionEvent e){
                Sc sc=new Sc();
                Connection c=sc.sc_connect();
                sc.sc_search(c,tex);
        }
}