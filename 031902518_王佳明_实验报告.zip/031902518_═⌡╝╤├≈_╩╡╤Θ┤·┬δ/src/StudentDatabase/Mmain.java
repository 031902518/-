package StudentDatabase;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
public class Mmain  extends JFrame {
    public static void main(String args[]) {
        MainInit init =new MainInit();
        init.Init();

    }
}
class MainInit extends JFrame{
    public void Init(){
        Container container =this.getContentPane();//容器，放东西


        URL resource=MainInit.class.getResource("1.png");
        Icon icon =new ImageIcon(resource);
        //把这个图标放在按钮上
        JLabel ll =new JLabel();
        ll.setIcon(icon);
        ll.setBounds(0,0,800,450);
        container.add(ll);
      //  container.add(ll);

        JButton button1=new JButton("学生表");
        JButton button2=new JButton("课程表");
        JButton button3=new JButton("选课表");

        //把这个图标放在按钮上

        container.setLayout(null);
        button1.setBounds(20,400,80,40);
        button1.setBackground(Color.orange);
        button2.setBounds(600,400,80,40);
        button2.setBackground(Color.orange);
        button3.setBounds(300,400,80,40);
        button3.setBackground(Color.orange);
        container.add(button1);
        container.add(button2);
        container.add(button3);
        this.setVisible(true);
        this.setSize(815,488);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        Init1Listener b1=new Init1Listener(true);
        button1.addActionListener(b1);

        Init2Listener b2=new Init2Listener(true);
        button2.addActionListener(b2);

        Init3Listener b3=new Init3Listener(true);
        button3.addActionListener(b3);
    }
}
class returnback implements ActionListener{
    public void actionPerformed(ActionEvent e){
        MainInit m=new MainInit();
        m.Init();
    }
}
class Init1Listener implements ActionListener {
    public  boolean flag;
    public Init1Listener( boolean f){
        this.flag=f;
    }
    public void actionPerformed(ActionEvent e){
        MyGUI mygui=new MyGUI();
        mygui.Init1(true);
    }

}

class Init2Listener implements  ActionListener{
    public  boolean flag;
    public Init2Listener( boolean f){
        this.flag=f;
    }
    public void actionPerformed(ActionEvent e){
        MyGUI mygui=new MyGUI();
        mygui.Init2(true);
    }
}

class Init3Listener implements  ActionListener{
    public  boolean flag;
    public Init3Listener( boolean f){
        this.flag=f;
    }
    public void actionPerformed(ActionEvent e){
        MyGUI mygui=new MyGUI();
        mygui.Init3(true);
    }
}