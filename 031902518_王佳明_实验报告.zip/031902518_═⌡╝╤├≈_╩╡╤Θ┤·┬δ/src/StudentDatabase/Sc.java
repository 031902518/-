package StudentDatabase;
import javax.swing.*;
import java.sql.*;
import java.util.Scanner;
public class Sc {
    //连接数据库
    public Connection sc_connect(){
        Connection c = null;
        Statement stmt = null;
        try {
            //连接数据库
            Class.forName("org.postgresql.Driver");
            c = DriverManager.getConnection("jdbc:postgresql://119.3.249.134:26000/postgres","wjm","wjm886652@");
            c.setAutoCommit(false);
            System.out.println("连接数据库成功！");

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.out.println("连接数据库失败");
            System.exit(0);
        }
        return c;
    }


    //插入数据
    public void sc_insert(Connection c,String sno,String cno,int grade){
        try {
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = "INSERT INTO Sc (sno,cno,grade) "
                    + "VALUES('"+sno+ "','"  +cno+   "','"  +grade+  "');";

            stmt.executeUpdate(sql);
            c.commit();
            System.out.println("新增数据成功！");

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.out.println("插入错误");
            System.exit(0);
        }
    }

    //更新数据
    public void sc_update(Connection c,String sql){
        try {
            Statement stmt = null;
            stmt = c.createStatement();
            stmt.executeUpdate(sql);
            c.commit();
            System.out.println("更新数据成功！");

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.out.println("更新错误");
            System.exit(0);
        }
    }

    //删除数据
    public void sc_delete(Connection c,String sql){
        try {
            Statement stmt = null;
            stmt = c.createStatement();
            System.out.println("请输入删除信息的课程号：");
            stmt.executeUpdate(sql);
            c.commit();
            System.out.println("删除数据成功！");
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.out.println("删除错误");
            System.exit(0);
        }
    }


    //查询数据
    public void sc_search(Connection c, JTextArea tex){

        try {
            Statement stmt = null;
            stmt = c.createStatement();
            String sql="select * from Sc ;";
            ResultSet rs = stmt.executeQuery(sql);
            tex.setText("");
            int sum=0;
            while(rs.next()){
                sum++;
                String sno = rs.getString("sno");
                String cno = rs.getString("cno");
                int grade= rs.getInt("grade");
                tex.append("\n"+"学生号:"+sno+"课程号:"+cno+"成绩:"+grade);
                System.out.println("\n"+"学生号:"+sno+"课程号:"+cno+"成绩:"+grade);
            }
            //tex.append("\n"+sum);
            System.out.println("查询数据成功！");
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.out.println("查询错误");
            System.exit(0);
        }
    }
}
