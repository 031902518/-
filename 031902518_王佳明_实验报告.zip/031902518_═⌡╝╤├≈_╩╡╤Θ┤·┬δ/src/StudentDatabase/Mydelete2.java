package StudentDatabase;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;

public class Mydelete2 extends JFrame {
    public Mydelete2(JTextArea textArea){
        textArea.setText("请输入你需要删除的数据，所具备的条件");
        Label label1= new Label("cno");
        label1.setSize(20,10);
        Label label2= new Label("cname");
        label2.setSize(20,10);
        Label label3= new Label("ccredit");
        label3.setSize(20,10);
        TextField mycno=new TextField(10);
        TextField mycname=new TextField(10);
        TextField mycredit=new TextField(10);
        Button button=new Button("certain");
        button.addActionListener(new DeleteListener(textArea,mycno,mycname,mycredit));
        setLayout(new FlowLayout());
        add(label1);
        add(mycno);
        add(label2);
        add(mycname);
        add(label3);
        add(mycredit);
        add(button);

        pack();
        setVisible(true);
    }


    class DeleteListener implements ActionListener {
        public TextField my_cno,my_cname,my_credit;
        public JTextArea textArea;
        public DeleteListener(JTextArea textArea,TextField cno,TextField cname,TextField ccredit){
            this.textArea=textArea;
            my_cno=cno;
            my_cname=cname;
            my_credit=ccredit;
        }
        @Override
        public void actionPerformed(ActionEvent e) {
            Course cou=new Course();
            Connection c=cou.cou_connect();
            String sql="delete from course where ";
            if(!my_cno.getText().isEmpty()){
                sql=sql+"cno='"+my_cno.getText()+"'";
            }
            if(sql!=null&&!my_cname.getText().isEmpty()){
                sql=sql+" and ";
            }
            if(!my_cname.getText().isEmpty()){
                sql=sql+"cname='"+my_cname.getText()+"'";
            }
            if(sql!=null&&!my_credit.getText().isEmpty()){
                sql=sql+" and ";
            }
            if(!my_credit.getText().isEmpty()){
                sql=sql+"ccredit='"+my_credit.getText()+"'";
            }

            sql=sql+";";
            System.out.println(sql);
            System.out.println(sql);
            cou.cou_delete(c,sql);
            //num3显示
            textArea.setText("删除成功");
            //num3.setText(""+(n1+n2));
            //清除
            my_cno.setText("");
            my_cname.setText("");
            my_credit.setText("");
            setVisible(false);
            Course ss=new Course();
            ss.cou_search(c,textArea);
        }
    }
}
