package StudentDatabase;
import javax.swing.*;
import java.sql.*;
import java.util.Scanner;

public class Course {


    //连接数据库
    public Connection cou_connect(){
        Connection c = null;
        Statement stmt = null;
        try {
            //连接数据库
            Class.forName("org.postgresql.Driver");
            c = DriverManager.getConnection("jdbc:postgresql://119.3.249.134:26000/postgres","wjm","wjm886652@");
            c.setAutoCommit(false);
            System.out.println("连接数据库成功！");

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.out.println("连接数据库失败");
            System.exit(0);
        }
        return c;
    }


    //插入数据
    public void cou_insert(Connection c,String cno,String cname,String ccredit){
        try {
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = "INSERT INTO course (cno,cname,ccredit) "
                    + "VALUES('"+cno+ "','"  +cname+   "','"  +ccredit+  "');";

            stmt.executeUpdate(sql);
            c.commit();
            System.out.println("新增数据成功！");

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.out.println("插入错误");
            System.exit(0);
        }
    }

    //更新数据
    public void cou_update(Connection c,String sql){
        try {
            Statement stmt = null;
            stmt = c.createStatement();
            stmt.executeUpdate(sql);
            c.commit();
            System.out.println("更新数据成功！");

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.out.println("更新错误");
            System.exit(0);
        }
    }

    //删除数据
    public void cou_delete(Connection c,String sql){
        try {
            Statement stmt = null;
            stmt = c.createStatement();
            System.out.println("请输入删除信息的课程号：");
            stmt.executeUpdate(sql);
            c.commit();
            System.out.println("删除数据成功！");
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.out.println("删除错误");
            System.exit(0);
        }
    }


    //查询数据
    public void cou_search(Connection c, JTextArea tex){

        try {
            Statement stmt = null;
            stmt = c.createStatement();
            String sql="select * from course ;";
            ResultSet rs = stmt.executeQuery(sql);
            tex.setText("");
            int sum=0;
            while(rs.next()){
                sum++;
                String cno = rs.getString("Cno");
                String cname = rs.getString("Cname");
                int ccredit= rs.getInt("Ccredit");
                tex.append("\n"+"课程号:"+cno+"课程名:"+cname+"学分:"+ccredit);
                System.out.println("\n"+"课程号:"+cno+"课程名:"+cname+"学分:"+ccredit);
            }
            //tex.append("\n"+sum);
            System.out.println("查询数据成功！");
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.out.println("查询错误");
            System.exit(0);
        }
    }


    public void cou_search2(Connection c, JTextArea tex,JComboBox flag){

        if(flag.getSelectedItem()==null)
            return;
        try {
            Statement stmt = null;
            stmt = c.createStatement();
            String sql=null;
            sql="select * from course ;";
            ResultSet rs = stmt.executeQuery(sql);
            tex.setText("");
            int max=-1;
            int min=1000;
            int count=0;
            double ave=0;
            int sum=0;
            while(rs.next()){
                String cno = rs.getString("Cno");
                String cname = rs.getString("cname");
                int ccredit = rs.getInt("ccredit");
                tex.append("\n"+"课程号:"+cno+"课程名:"+cname+"学分:"+ccredit);
                System.out.println("\n"+"课程号:"+cno+"课程名:"+cname+"学分:"+ccredit);
                sum+=ccredit;
                count++;
                if(max<ccredit) {
                    max=ccredit;
                }
                if(min>ccredit){
                    min=ccredit;
                }
            }
            ave=sum *1.0/count;
            if(flag.getSelectedItem()=="课程个数")
                tex.append("\n课程个数："+count);
            else if(flag.getSelectedItem()=="课程最大学分")
                tex.append("\n课程最大学分："+max);
            else if(flag.getSelectedItem()=="课程最小学分")
                tex.append("\n课程最小学分："+min);
            else if(flag.getSelectedItem()=="课程平均学分")
                tex.append("\n课程平均学分："+ave);

            //System.out.println(flag.getSelectedItem());
            System.out.println("查询数据成功！");
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.out.println("查询错误");
            System.exit(0);
        }
    }

}
