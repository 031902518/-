package StudentDatabase;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
public class Myinsert2  extends JFrame {

    public Myinsert2(JTextArea textArea){
        textArea.setText("请输入你要增加的数据:课程号cno,课程名cname,学分ccredit");
        Label label1= new Label("cno");
        label1.setSize(20,10);
        Label label2= new Label("cname");
        label2.setSize(20,10);
        Label label3= new Label("Ccredit");
        label3.setSize(20,10);
        TextField mycno=new TextField(10);
        TextField mycname=new TextField(10);
        TextField myCcredit=new TextField(10);
        Button button=new Button("certain");
        button.addActionListener(new InsertListener(textArea,mycno,mycname,myCcredit));
        setLayout(new FlowLayout());
        add(label1);
        add(mycno);
        add(label2);
        add(mycname);
        add(label3);
        add(myCcredit);
        add(button);

        pack();
        setVisible(true);
    }

    class InsertListener implements ActionListener{
        public TextField my_cno,my_cname,my_ccredit;
        public JTextArea textArea;
        public InsertListener(JTextArea textArea,TextField cno,TextField cname,TextField ccredit){
            this.textArea=textArea;
            my_cno=cno;
            my_cname=cname;
            my_ccredit=ccredit;
        }
        @Override
        public void actionPerformed(ActionEvent e) {
            Course cou=new Course();
            Connection c=cou.cou_connect();
            cou.cou_insert(c,my_cno.getText(),my_cname.getText(),my_ccredit.getText());
            //num3显示
            textArea.setText("插入成功");
            //num3.setText(""+(n1+n2));
            //清除
            my_cno.setText("");
            my_cname.setText("");
            my_ccredit.setText("");
            setVisible(false);
            Course ss=new Course();
            ss.cou_search(c,textArea);
        }
    }
}

