package StudentDatabase;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;

public class Mydelete3 extends JFrame {
    public Mydelete3(JTextArea textArea){
        textArea.setText("请输入你需要删除的数据，所具备的条件");
        Label label1= new Label("sno");
        label1.setSize(20,10);
        Label label2= new Label("cno");
        label2.setSize(20,10);
        Label label3= new Label("grade");
        label3.setSize(20,10);
        TextField mysno=new TextField(10);
        TextField mycno=new TextField(10);
        TextField mygrade=new TextField(10);
        Button button=new Button("certain");
        button.addActionListener(new DeleteListener(textArea,mysno,mycno,mygrade));
        setLayout(new FlowLayout());
        add(label1);
        add(mysno);
        add(label2);
        add(mycno);
        add(label3);
        add(mygrade);
        add(button);
        pack();
        setVisible(true);
    }


    class DeleteListener implements ActionListener {
        public TextField my_sno,my_cno,my_grade;
        public JTextArea textArea;
        public DeleteListener(JTextArea textArea,TextField sno,TextField cno,TextField grade){
            this.textArea=textArea;
            my_cno=cno;
            my_sno=sno;
            my_grade=grade;
        }
        @Override
        public void actionPerformed(ActionEvent e) {
            Sc sc=new Sc();
            Connection c=sc.sc_connect();
            String sql="delete from Sc where ";
            if(!my_sno.getText().isEmpty()){
                sql=sql+"sno='"+my_sno.getText()+"'";
            }
            if(sql!=null&&!my_cno.getText().isEmpty()){
                sql=sql+" and ";
            }
            if(!my_cno.getText().isEmpty()){
                sql=sql+"cno='"+my_cno.getText()+"'";
            }
            if(sql!=null&&!my_grade.getText().isEmpty()){
                sql=sql+" and ";
            }
            if(!my_grade.getText().isEmpty()){
                sql=sql+"grade='"+my_grade.getText()+"'";
            }

            sql=sql+";";
            System.out.println(sql);
            System.out.println(sql);
            sc.sc_delete(c,sql);
            //num3显示
            textArea.setText("删除成功");
            //num3.setText(""+(n1+n2));
            //清除
            my_cno.setText("");
            my_sno.setText("");
            my_grade.setText("");
            setVisible(false);
            Sc ss=new Sc();
            ss.sc_search(c,textArea);
        }
    }
}
