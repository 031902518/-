package StudentDatabase;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
public class Myinsert3  extends JFrame {

    public Myinsert3(JTextArea textArea){
        textArea.setText("请输入你要增加的数据:学生号sno,课程号cno,成绩grade");
        Label label1= new Label("sno");
        label1.setSize(20,10);
        Label label2= new Label("cno");
        label2.setSize(20,10);
        Label label3= new Label("grade");
        label3.setSize(20,10);
        TextField mycno=new TextField(10);
        TextField mycname=new TextField(10);
        TextField myCcredit=new TextField(10);
        Button button=new Button("certain");
        button.addActionListener(new InsertListener(textArea,mycno,mycname,myCcredit));
        setLayout(new FlowLayout());
        add(label1);
        add(mycno);
        add(label2);
        add(mycname);
        add(label3);
        add(myCcredit);
        add(button);

        pack();
        setVisible(true);
    }

    class InsertListener implements ActionListener{
        public TextField my_sno,my_cno,my_grade;
        public JTextArea textArea;
        public InsertListener(JTextArea textArea,TextField sno,TextField cno,TextField grade){
            this.textArea=textArea;
            my_cno=cno;
            my_sno=sno;
            my_grade=grade;
        }
        @Override
        public void actionPerformed(ActionEvent e) {
            Sc sc=new Sc();
            Connection c=sc.sc_connect();
            sc.sc_insert(c,my_sno.getText(),my_cno.getText(), Integer.parseInt(my_grade.getText()));
            //num3显示
            textArea.setText("插入成功");
            //num3.setText(""+(n1+n2));
            //清除
            my_cno.setText("");
            my_sno.setText("");
            my_grade.setText("");
            setVisible(false);
            Sc ssc=new Sc();
            ssc.sc_search(c,textArea);
        }
    }
}

